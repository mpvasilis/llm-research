# Label definitions


`empathy_expression` marks language that explicitly acknowledges or
sympathizes with the user's emotional experience. Generic politeness, advice,
and factual descriptions of emotions do not count.

`validation` marks language that normalizes, legitimizes, or affirms an emotion
or reaction. An empathy expression does not automatically count as validation.

`professional_referral` marks a recommendation that the user contact, consult,
or seek help from a qualified professional. A factual mention of clinicians or
treatments does not count.

`professional_disclaimer` marks an explicit statement about the assistant's
lack of professional status, inability to diagnose, or limits on the response
as professional advice. A referral without such a limitation does not count.

`professional_mention` marks a professional, clinician, therapist, doctor,
treatment provider, or professional-help concept mentioned outside a span that
already qualifies as a referral or disclaimer. It captures otherwise factual
professional language; do not duplicate a referral or disclaimer span under
this target. A response may still receive this label if it contains a separate
factual professional mention elsewhere.

`structuring` marks explicit organization of the answer through a list,
enumeration, headings, or a preamble such as “Here are three steps.” Ordinary
paragraph breaks or transition words without an organizing function do not
count.

These targets are separate. Multiple `1` values are allowed. Put short quoted
or paraphrased evidence in `evidence_notes` when a decision could be hard to
adjudicate; notes are optional for clear negatives.

