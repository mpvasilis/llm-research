# Anonymous BlackboxNLP supplementary package

This package contains the anonymous review PDF and source, deterministic
analysis scripts, prompt battery, and machine-readable result artifacts.

The 140-prompt evaluation, 90-prompt stagewise subset, and separate
120-sentence AI-only audit are distinct samples. The AI audit is not human
validation. Run the commands below from this directory after installing
`requirements-paper.txt`:

```text
python -m experiments.monte_carlo_correction
python -m experiments.derive_paper_stats
python -m experiments.between_condition_stats
python -m experiments.stage_condition_gaps
python -m experiments.multiple_testing
python -m experiments.threshold_robustness
python -m experiments.recount_sft_olmo2
python -m experiments.audit_cluster_bootstrap
```

The completed four-seed matched-control extension is included with its strict
24-test `status=complete` artifact and three-threshold sensitivity sweep. The
dated bundle manifest records the incoming aggregate archive hash and the
boundary of the independent checks performed on it.
