# Anonymous BlackboxNLP supplementary package

This package contains the anonymous review PDF and source, analysis and
generation scripts, the complete prompt battery, the recovered final-7B raw
responses, and machine-readable result artifacts.

The 140-prompt evaluation, 90-prompt stagewise subset, and separate
120-sentence AI-only audit are distinct samples. The AI audit is not human
validation. `experiments/prompts.json` is the reused 12-prompt pilot;
`experiments/prompts_full.json` is the complete 140-prompt battery. Raw
generations are available only for the final 7B checkpoint (700 responses);
stagewise raw caches were not recovered. Run the commands below from this
directory after installing
`requirements-paper.txt`:

```text
python -m experiments.monte_carlo_correction
python -m experiments.derive_paper_stats
python -m experiments.between_condition_stats
python -m experiments.stage_condition_gaps
python -m experiments.multiple_testing
python -m experiments.threshold_robustness
python -m experiments.recount_sft_olmo2
python -m experiments.audit_cluster_bootstrap
python -m experiments.raw_output_robustness
python -m experiments.dpo_phrase_robustness
```

The final two commands load the e5 model and remotely scan the public DPO
parquet mixtures, respectively. Their released JSON outputs include detector
component/fixed-window tests and phrase/source/within-pair-length DPO checks.

The completed four-seed axis-targeted-control extension is included with its strict
24-test `status=complete` artifact and three-threshold sensitivity sweep. The
dated bundle manifest records the incoming aggregate archive hash and the
boundary of the independent checks performed on it. The revision manifest
separately records hashes and the exact scope of newly recovered raw data.
